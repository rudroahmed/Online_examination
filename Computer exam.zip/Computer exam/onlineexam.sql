-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 27, 2019 at 08:19 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `exam` varchar(25) NOT NULL,
  `subname` varchar(25) NOT NULL,
  `subcode` varchar(25) NOT NULL,
  `registernum` varchar(25) NOT NULL,
  `quenum` int(10) NOT NULL,
  `answer` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`exam`, `subname`, `subcode`, `registernum`, `quenum`, `answer`) VALUES
('First Exam', 'java', 'java-123', 'Rn1000', 10, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 9, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 8, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 7, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 6, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 5, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 4, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 3, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 2, 1),
('First Exam', 'java', 'java-123', 'Rn1000', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mark`
--

DROP TABLE IF EXISTS `mark`;
CREATE TABLE IF NOT EXISTS `mark` (
  `subcode` varchar(25) NOT NULL,
  `regnum` varchar(25) NOT NULL,
  `totalque` int(25) NOT NULL,
  `correctans` int(25) NOT NULL,
  `falseans` int(25) NOT NULL,
  `avgmark` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mark`
--

INSERT INTO `mark` (`subcode`, `regnum`, `totalque`, `correctans`, `falseans`, `avgmark`) VALUES
('java-123', 'Rn1000', 10, 4, 6, '40.0%');

-- --------------------------------------------------------

--
-- Table structure for table `setpaper`
--

DROP TABLE IF EXISTS `setpaper`;
CREATE TABLE IF NOT EXISTS `setpaper` (
  `exam` varchar(50) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `subcode` varchar(20) NOT NULL,
  `grade` varchar(20) NOT NULL,
  `queNumber` int(25) NOT NULL,
  `que` varchar(250) NOT NULL,
  `ans01` varchar(100) NOT NULL,
  `ans02` varchar(100) NOT NULL,
  `ans03` varchar(100) NOT NULL,
  `ans04` varchar(100) NOT NULL,
  `correctans` varchar(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setpaper`
--

INSERT INTO `setpaper` (`exam`, `subject`, `subcode`, `grade`, `queNumber`, `que`, `ans01`, `ans02`, `ans03`, `ans04`, `correctans`) VALUES
('First Exam', 'java', 'java-123', 'Grade 02', 1, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', '. Professional Qualifications ', '. Professional Qualifications ', '. Professional Qualifications ', '2'),
('First Exam', 'java', 'java-123', 'Grade 02', 3, 'Applications which are forwarded without complying to the guidelines \nspecified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '1'),
('First Exam', 'java', 'java-123', 'Grade 02', 4, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '3'),
('First Exam', 'java', 'java-123', 'Grade 02', 5, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '3'),
('First Exam', 'java', 'java-123', 'Grade 02', 6, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '1'),
('First Exam', 'java', 'java-123', 'Grade 02', 7, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '4'),
('First Exam', 'java', 'java-123', 'Grade 02', 8, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '2'),
('First Exam', 'java', 'java-123', 'Grade 02', 9, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '4'),
('First Exam', 'java', 'java-123', 'Grade 02', 10, 'Applications which are forwarded without complying to the guidelines specified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '1'),
('First Exam', 'java', 'java-123', 'Grade 02', 2, 'Applications which are forwarded without complying to the guidelines \nspecified in the ', 'Applications which are ', 'Professional Qualifications ', 'Professional Qualifications ', 'Professional Qualifications ', '1');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `rNumber` varchar(25) NOT NULL,
  `sName` varchar(50) NOT NULL,
  `sbirthday` varchar(25) NOT NULL,
  `grade` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`rNumber`, `sName`, `sbirthday`, `grade`, `password`) VALUES
('Rn1000', 'jhiu', '2019-09-05', 'Grade 02', '123'),
('Rn1001', 'klmkl', '2019-09-12', 'Grade 03', '12');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
